export const FORMATS = {
    TEXT: {
        'b': 'bold',
        'i': 'italic',
        'u': 'underline'
    }
}