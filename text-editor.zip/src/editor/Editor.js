import React, { Component, Fragment } from 'react';
import _ from 'lodash';

import ControlPanel from "../control-panel/ControlPanel";
import FileZone from "../file-zone/FileZone";
import { formatWord, getSelection } from '../shared/textUtils';

class Editor extends Component {

    constructor(props){
        super(props);

        this.state = {
            formattedText: props.text,
            selection: '',
        };

        this.debouncedUpdateSelection = _.debounce(this.updateSelection, 500);
    }
    
    componentDidMount(){
        document.addEventListener("selectionchange", this.debouncedUpdateSelection);
    }

    componentWillUnmount(){
        document.removeEventListener("selectionchange", this.debouncedUpdateSelection);
    }

    componentDidUpdate(prevProps){
        if(prevProps.text !== this.props.text)
        this.setState({ formattedText: this.props.text})
    }

    updateSelection = evt => {
        const selection = getSelection();
        
        this.setState({ selection });
    }

    handleAction = (evt) => {
        const { selection } = this.state;
        const format = evt.currentTarget.value;
        const formattedText = formatWord(selection, format);
        // todo implement formatWord correclty
        // this.setState({ formattedText });
    }

    render() {
        return (
            <Fragment>
                    <ControlPanel onClick={this.handleAction}/>
                    <FileZone text={this.state.formattedText} />
            </Fragment>
        );
    }
}

export default Editor;
