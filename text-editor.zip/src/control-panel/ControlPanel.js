import React from 'react';
import './ControlPanel.css';

const ControlPanel = ({ onClick }) => (
    <div id="control-panel">
        <div id="format-actions">
            <button className="format-action" type="button" value="bold" onClick={onClick}><b>B</b></button>
            <button className="format-action" type="button" value="italic" onClick={onClick}><i>I</i></button>
            <button className="format-action" type="button" value="underline" onClick={onClick}><u>U</u></button>
        </div>
    </div>
)

export default ControlPanel;
