import React from 'react';

import { Text } from '../components/Text';

import './FileZone.css';

const FileZone = (props) => (
    <div id="file-zone">
        <div id="file">
            <Text>
                {props.text}
            </Text>
        </div>
    </div>
);

export default FileZone;
