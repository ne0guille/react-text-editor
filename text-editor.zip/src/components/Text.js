import React from 'react';

export const Text = props => {
console.log(props)
        return (
            <div id="text" style={props.textStyle}>
              {props.children}
            </div>
        );
}

export default Text;
